export const v4 = () => 'uuid-1';
