// Minimal dayjs mock returning a fixed ISO timestamp
export default () => ({
  toISOString: () => 't',
});
