# Cogira Backend

## Pre-commit Hooks

Automated checks enforce:

- No direct commits to main branch
- Prettier code formatting
- Constitution files must be finalized

Setup: `npm install`
